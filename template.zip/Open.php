 <!DOCTYPE html>

<title>Open Offers</title>
 
<head>
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tutormatch";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}

session_start();
$user=$_SESSION['tutorid'];

$sql = "SELECT subjects.subjectname, offers.language, offers.offerfee, offers.offerid, offers.offerstatus, offers.tutorid FROM offers, subjects WHERE subjects.subjectid=offers.subjectid AND offers.tutorid='$user' AND offers.offerstatus='Open' ORDER BY offers.offerid DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<br><br><center><table border><tr><th>Subject name</th><th>Language</th><th>Offer fee</th></tr>";
     // output data of each row
     while($row = $result->fetch_assoc()) {
       
         $offerid = $row['offerid'];
         echo "<tr><td>". $row['subjectname']. "</td><td>". $row['language']. "</td><td>" . $row['offerfee'] . "</td><td></center><a href ='openstudents.php?offerid=$offerid'>Students</a></td><td><a href='startclass.php?offerid=$offerid'>Start Class</a></td><td><a href='closeoffer.php?offerid=$offerid'>Close offer</a></td></tr>";
     }
} else {
     echo "<br><br><h2><center>No in progress offers</center></h2>";
}

$conn->close();
?> 

</body>
</html>