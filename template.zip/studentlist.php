 <!DOCTYPE html>

<title>Students List</title>
 
<head>
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tutormatch";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}

session_start();
$user=$_SESSION['tutorid'];

$offer=$_GET['offerid'];

$sql = "SELECT tutee.tuteename, tutee.tuteeemail, tutee.tuteephone, registration.offerid, registration.registrationid, registration.status FROM tutee, registration WHERE registration.tuteeid=tutee.tuteeid AND registration.offerid='$offer' AND (registration.status='registered' OR registration.status='withdrawed' OR registration.status='deleted')";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    echo "<br><br><center><table border><tr><th>Tute ename</th><th>Tutee email</th><th>Tutee phone</th><th>Status</th></tr>";
     // output data of each row
     while($row = $result->fetch_assoc()) {
       
         $registration = $row['registrationid'];
         echo "<tr><td>". $row['tuteename']. "</td><td>". $row['tuteeemail']. "</td><td>" . $row['tuteephone'] . "</td><td>" . $row['status'] ."</td><td><a href='deletestudent.php?id=$registration'>Delete</a></center></td></tr>";
     }
} else {
     echo "<br><br><h2><center>No Students</center></h2>";
}

$conn->close();
?> 

</body>
</html>