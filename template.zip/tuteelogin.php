<html>
 
<title>TutorMatch</title>
 
<head>
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>

<body>

<br><br>

<b>

<?php

if(isset($_POST['login']) && isset($_POST['password']))
{

    include("bd.php");
 
    $login=htmlspecialchars(trim($_POST['login']));
    $password=htmlspecialchars(trim($_POST['password']));
 
    $res=mysql_query("SELECT * FROM `tutee` WHERE `tuteelogin`='$login' ");
    if($res == FALSE) { 
      die(mysql_error()); // TODO: better error handling
    }
    
    $data=mysql_fetch_array($res);
 
    if(empty($data['tuteelogin']))
    {
        die("Your password or login is incorrect");
    }
    if($password!=$data['tuteepassword'])
    {
        die("Your password or login is incorrect");
    }
    session_start();
 
    $_SESSION['tuteelogin']=$data['tuteelogin'];
    $_SESSION['tuteeid']=$data['tuteeid'];

    header("location: tuteeindex.php");
}
 