 <!DOCTYPE html>

<title>Search Results</title>
 
<head>
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>
<body>
<br>

<center>
<a href='InProgress.php'>In Progress</a><br>
<a href='Open.php'>Open</a><br>
<a href='Ended.php'>Ended</a><br>
<a href='index.php'>My page</a><br>
</center>

</body>
</html>