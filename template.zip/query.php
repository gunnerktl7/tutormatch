  <!DOCTYPE HTML>
<title>TutorMatch</title>
<head> 
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>
<body>
  <form method="POST" action="search.php">

  <center>Find tutor:<br>
  <b>Insert name of subject </b><input type="text" maxlength="20" NAME="lesson"> <I>(example: Calculus I)</I>
  Language:
  <select name="lang">
      <option value="English">English</option>
      <option value="Korean">Korean</option>
  
  <br><input type="submit" name="submit" value="Find">

  </form>
</body>
</html> 