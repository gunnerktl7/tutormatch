<html>
 
<title>TutorMatch</title>
 
<head>
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>

<body>

<br><br>

<b>

<?php

if(isset($_POST['login']) && isset($_POST['password']))
{
    $login=htmlspecialchars(trim($_POST['login']));
    $password=htmlspecialchars(trim($_POST['password']));
    $cpassword=htmlspecialchars(trim($_POST['cpassword']));
    $name=htmlspecialchars(trim($_POST['name']));
    $email=htmlspecialchars(trim($_POST['email']));
    $phone=htmlspecialchars(trim($_POST['phone']));
    $year=htmlspecialchars(trim($_POST['year']));
 
    if($login=="" || $password=="" || $name=="" || $email=="" || $year=="")
    {
        die("Fill all");
    }
 
    include("bd.php");
    
    
    $res=mysql_query("SELECT `tuteelogin` FROM `tutee` WHERE `tuteelogin`='$login' ");
    
    if($res==FALSE) {
      die(mysql_error());
    }
 
    $data=mysql_fetch_array($res);
 
    if(!empty($data['tuteelogin']))
    {
        die("Such login already exists");
    }
 
    if(strlen($password)<6){
        die("Your password cannot be less than 7 symbols");
    }
    if ($password!=$cpassword) {
      die("Your passwords does not match");
      
    }
 
    $query="INSERT INTO `tutee` (`tuteelogin`,`tuteename`,`tuteepassword`,`tuteeemail`,`tuteephone`, `tuteeyear`,`activity`) VALUES('$login','$name','$password','$email','$phone', '$year', 'YES') ";
    $result=mysql_query($query);
 
    if($result==true)
    {   echo "Your registration is comleteted<b><br>";
        echo "Please, go to the <a href='main.php'>Mainpage</a>";
    }
    else
    {
        echo "Error! ----> ". mysql_error();
    }
}
?>

</body>
</html>