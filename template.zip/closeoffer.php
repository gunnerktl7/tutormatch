 <html>
 
<title>TutorMatch</title>
 
<head>
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>

<body>

<br><br>

<b>

<?php

include("bd.php");

$offerid = $_GET['offerid'];

$query="UPDATE `offers` SET `offerstatus`='Closed' WHERE `offerid`='$offerid'";
$result=mysql_query($query);

$sql="UPDATE `registration` SET `status`='declined' WHERE `offerid`='$offerid'";
$res=mysql_query($sql);
 
 
if($result==true) {   
    echo "Offer changed from Open to Closed<b><br>";
    echo "Please, go to <a href='tutormyoffers.php'>My offers</a>";
  }
else {
  echo "Error! ----> ". mysql_error();
  }