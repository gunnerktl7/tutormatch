<?php
$mysql_connect=mysql_connect("localhost","root","");
$db=mysql_select_db("tutormatch");
?>