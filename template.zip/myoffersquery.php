 <!DOCTYPE html>

<title>Students List</title>
 
<head>
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tutormatch";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}

session_start();
$user=$_SESSION['tutorid'];


$sql = "SELECT tutee.tuteename, tutee.tuteeemail, tutee.tuteephone, registration.registrationid, registration.status, subjects.subjectname, offers.tutorid FROM tutee, registration, subjects, offers WHERE registration.tuteeid=tutee.tuteeid AND registration.offerid=offers.offerid AND subjects.subjectid=offers.subjectid AND offers.tutorid='$user' AND registration.status='unknown'";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    echo "<br><br><center><table border><tr><th>Tutee name</th><th>Tutee email</th><th>Tutee Phone</th><th>Offer status</th><th>Subject name</th></tr>";
     // output data of each row
     while($row = $result->fetch_assoc()) {
       
         $registration = $row['registrationid'];
         echo "<tr><td>". $row['tuteename']. "</td><td>". $row['tuteeemail']. "</td><td>" . $row['tuteephone'] . "</td><td>" . $row['status'] ."</td><td>".$row['subjectname']."</center></td><td><a href='addtooffer.php?id=$registration'>Add</a></td><td><a href='declineoffer.php?id=$registration'>Decline</a></td></tr>";
     }
} else {
     echo "<br><br><h2><center>No Students</center></h2>";
}

$conn->close();
?> 

</body>
</html>