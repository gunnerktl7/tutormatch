<html>
 
<title>TutorMatch</title>
 
<head>
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>
<body>

<br><br><b>

<?php

if (isset($_POST['lesson']) && isset($_POST['lang']) && isset($_POST['fee'])){

$lesson=$_POST['lesson'];
$lang=$_POST['lang'];
$fee=$_POST['fee'];


if($lesson=="" || $fee==""){
  die("Fill all");
}
 
include("bd.php");

session_start();
$user=$_SESSION['tutorid'];

$res=mysql_query("SELECT * FROM `users` WHERE `tutorid`='$user'");

if($res == FALSE) { 
  die("Please, log in"); // TODO: better error handling
}

$user_data=mysql_fetch_array($res);
$tutorid=$user_data['tutorid'];

include("bd.php");


$res=mysql_query("SELECT * FROM `subjects` WHERE `subjectname`='$lesson'");

if(mysql_num_rows($res)==0) { 
  die("Such subject is not registered, please, add subject first"); // TODO: better error handling
}

$user_data=mysql_fetch_array($res);
$lessonid=$user_data['subjectid'];

$status="Open";

$query="INSERT INTO `offers` (`tutorid`,`subjectid`,`language`,`offerfee`,`offerstatus`) VALUES('$tutorid','$lessonid','$lang','$fee','$status')";
$result=mysql_query($query);

if($result==true){
  echo "You added offer<br>";
  echo "Please, return <a href='index.php'>my page</a><br>";
}else {
  die(mysql_error());
}
}else{
  die("");
}
?>