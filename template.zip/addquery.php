<html>
 
<title>TutorMatch</title>
 
<head>
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>
<body>

<br><br><b>

<?php

include("bd.php");

session_start();
$user=$_SESSION['tuteeid'];

$res=mysql_query("SELECT * FROM `tutee` WHERE `tuteeid`='$user'");

if($res == FALSE) { 
  die("Please, log in"); // TODO: better error handling
}

$user_data=mysql_fetch_array($res);
$tuteeid=$user_data['tuteeid'];

$offerid = $_GET['offerid'];;

$status="unknown";

$query="INSERT INTO `registration` (`tuteeid`,`offerid`,`status`) VALUES('$tuteeid','$offerid','$status')";
$result=mysql_query($query);
 
if($result==true){   
  echo "You send request to join this offer<br>";
  echo "Please, go to the <a href='tuteeindex.php'>My page</a><br>";
}else {
  die(mysql_error());

}
?>