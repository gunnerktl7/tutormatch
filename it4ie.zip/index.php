<html>
 
<title>TutorMatch</title>
 
<head>
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>
<body> 
<?php
session_start();
if(!isset($_SESSION['tutorlogin']) || !isset($_SESSION['tutorid'])) {
  ?>
  <form action="register.php" method="POST">
  <center><h2>Registration for tutor</h2></center>
  
  <TABLE ALIGN="center">
      <TR ALIGN="center">
        <TD COLSPAN="2"> <h3>Insert your information</h3></TD>
      </TR>
      <TR>
        <TD>Login</TD>
        <TD><INPUT TYPE="text" MAXLENGTH="12" NAME="login"> <I>(Enter your login up to 12 symbols)</I></TD>
      </TR>
      <TR>
        <TD>Name</TD>
        <TD><INPUT TYPE="text" MAXLENGTH="30" NAME="name"> <I>(Enter your name)</I></TD>
      </TR>
      <TR>
        <TD>Password</TD>
        <TD><INPUT TYPE="password" MAXLENGTH="12" NAME="password"> <I>(Make password between 6 and 12 characters)</I></TD>
      </TR>
      <TR>
        <TD>Confirm</TD>
        <TD><INPUT TYPE="password" MAXLENGTH="12" NAME="cpassword"> <I>(Please, confirm your password)</I></TD>
      </TR>
      <TR>
        <TD>E-mail</TD>
        <TD><INPUT TYPE="text" MAXLENGTH="40" NAME="email"> <I>(Enter your e-mail)</I></TD>
      </TR>
      <TR>
        <TD>Phone number</TD>
        <TD><INPUT TYPE="text" MAXLENGTH="11" NAME="phone"> <I>(Enter your phone number)</I></TD>
      </TR>
        <TD>Year</TD>
        <TD>
          <SELECT NAME="year">
            <OPTION VALUE="selected">Select your year</OPTION>
            <OPTION VALUE="Freshman">Freshman</OPTION>
            <OPTION VALUE="Sophomore">Sophomore</OPTION>
            <OPTION VALUE="Junior">Junior</OPTION>
            <OPTION VALUE="Senior">Senior</OPTION>
            <OPTION VALUE="ExtraYear">Extra year</OPTION>
          </SELECT>
        </TD>
      </TR>
      <TR align="center">
        <TD colspan="2"><INPUT id="button" type="submit" name="submit" value="Sign-Up">
        <INPUT TYPE="reset" NAME="cancle" VALUE="Cancle"></TD>
      </TR>
    </TABLE>
  </form>
  <br>
  <center>
    <h4><i>If you are already registered, please, log in</i></h4>
  </center>
  <br>
  <form action="login.php" method="POST">
    <table align="center">
      <tr align="center">
        <td colspan="2"><h3>Login</h3></td>
      <tr>
        <td>Login</td>
        <td><input type="text" name="login"></td>
      </tr>
      <tr>
        <td>Password</td>
        <td><input type="password" name="password"></td>
      </td>
      <tr align="center">
        <td colspan="2"><input type="submit" value="Login"></td>
      </tr>
    </table>
  </form>
<br><br><center><a href='main.php'>Mainpage</a></center>
  <?php
}
if(isset($_SESSION['tutorlogin']) && isset($_SESSION['tutorid']))
{
 
    include("bd.php");
    $user=$_SESSION['tutorlogin'];
    $res=mysql_query("SELECT * FROM `users` WHERE `tutorlogin`='$user'");
    if($res == FALSE) { 
      die(mysql_error()); // TODO: better error handling
    }
    $user_data=mysql_fetch_array($res);
    
    echo "<center>";
    echo "Your login: <b>". $user_data['tutorlogin']."</b><br>";
    echo "Your name: <b>". $user_data['tutorname']."</b><br>";
    echo "Your email: <b>". $user_data['tutoremail']."</b><br>";
    echo "Phone: <b>". $user_data['tutorphone']."</b><br>";
    echo "Current year: <b>". $user_data['tutoryear']."</b><br>";
    echo "<a href='offer.php'>Add offers</a><br>";
    echo "<a href='main.php'>Main</a><br>";
    echo "<a href='exit.php'>Logout</a>";
    echo "</center>";
}
?>
</body>
 
</html>