<!DOCTYPE HTML>
<title>TutorMatch</title>
<head>
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>
<body>
<form method="POST" action="add.php">
  <center>
  <h2>Hey, you can add your offers here</h2><br>
  <table>
  <tr>
    <td>Name of lesson</td>
    <td><input type="text" maxlength="20" NAME="lesson"> <I>(example: Calculus I)</I></TD>
  </tr>
  <tr>
    <td>Language</td>
    <td><select name="lang">
      <option value="English">English</option>
      <option value="Korean">Korean</option>
    </td>
  </tr>
  <tr>
    <td>Fee per hour</td>
    <td><input type="number" name="fee" min="0"><i>Insert fee in KRW</i></td>
  </tr>
  <tr align="center">
    <td colspan="2"><input type="submit" name="submit" value="Add">
    <input type="reset" value="Cancle"></td><br>
  </tr>
</table><br>
<center><a href='index.php'>Back</a>
</form>

</body>
</html> 