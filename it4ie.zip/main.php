<!DOCTYPE HTML>
<title>TutorMatch</title>
<head> 
  <TABLE>
      <TR>
        <TD><IMG SRC="files/kaistlogo.png" WIDTH="150" HEIGHT="60" BORDER="0" ALT="0"></TD>
        <TD><B><H1>TutorMatch</H1></B></TD>
      </TR>
  </TABLE>
</head>
<body>
  <div>
  <h2><b>Welcome to the TutorMatch, service for you, if you are looking for knowledge</b></h2><br>
  <h3>If you are <b>tutor</b> you can login or signup <a href="index.php">here</a></h2><br><br>
  <form method="POST" action="search.php">
  <center>Find tutor:<br>
  <b>Insert name of subject </b><input type="text" maxlength="20" NAME="lesson"> <I>(example: Calculus I)</I>
  Language:
  <select name="lang">
      <option value="English">English</option>
      <option value="Korean">Korean</option>
  
  <br><input type="submit" name="submit" value="Find">
  </form>
</body>
</html> 